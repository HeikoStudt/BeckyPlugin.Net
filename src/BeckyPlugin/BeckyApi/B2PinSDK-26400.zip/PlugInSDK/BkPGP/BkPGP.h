
#ifdef BKPGP_EXPORTS
#define BKPGP_API __declspec(dllexport)
#else
#define BKPGP_API __declspec(dllimport)
#endif


#include "resource.h"

