//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BkPGP.rc
//
#define IDS_PGP_DECRYPT                 1
#define IDS_PGP_SIGN                    2
#define IDS_PGP_ENCRYPT                 3
#define IDS_PGP_SIGNENCRYPT             4
#define IDS_PGP_ATTACHKEY               5
#define IDS_PGPMENU_DECRYPT             6
#define IDS_PGPMENU_SIGN                7
#define IDS_PGPMENU_ENCRYPT             8
#define IDS_PGPMENU_SIGNENCRYPT         9
#define IDS_PGPMENU_ATTACHKEY           10
#define IDS_PGP_SETUP                   11
#define IDS_PGPMENU_SETUP               12
#define IDS_PGP_ERROR                   13
#define IDS_PGP_NOTPROCESSED            14
#define IDS_PGP_NORECIPIENT             15
#define IDS_PIN_NAME                    16
#define IDS_PIN_DESCRIPTION             17
#define IDS_NOHTML                      18
#define IDD_PGP_SETUP                   102
#define IDC_EDIT1                       112
#define IDC_EDIT2                       113
#define IDD_DLGINPUTPASS                202
#define IDD_DLGVIEW                     203
#define IDD_DLGINPUTID                  396
#define IDD_DLGINPUTPASS1               397
#define IDC_EDTPGPVERSION               1001
#define IDC_CHKPGPMIME                  1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
