//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by _b2icon_.rc
//
#define IDS_DESCRIPTION                 1
#define IDR_MAINFRAME                   101
#define IDR_ADDRESSBOOK                 102
#define IDR_COMPOSEFRAME                103
#define IDR_HTMLEDITOR                  104
#define IDR_ADDRESSBOOK_120             105
#define IDR_COMPOSEFRAME_120            106
#define IDR_HTMLEDITOR_120              107
#define IDR_MAINFRAME1                  108
#define IDR_MAINFRAME_120               108

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
