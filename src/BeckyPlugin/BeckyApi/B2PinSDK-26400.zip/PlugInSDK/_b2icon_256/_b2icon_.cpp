// _b2icon_.cpp : DLL �A�v���P�[�V�����p�̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "resource.h"       // ���C�� �V���{��


////////////////////////////////////////////////////////////////////////////////////
// Template file for plugin.
//
// You can modify and redistribute this file without any permission.
//
// Note:
// Create a sub folder under "PlugInSDK" folder. e.g. "PlugInSDK\MyProject\" and
// place your project files there.

#include "BeckyAPI.h"
#include "BkCommon.h"

CBeckyAPI bka; // You can have only one instance in a project.

HINSTANCE g_hInstance = NULL;

char szIni[_MAX_PATH+2]; // Ini file to save your plugin settings.

int g_dpi = 96;
LONGLONG g_colors = 256;
int g_cxsmicon = 16;
int g_cysmicon = 16;

/////////////////////////////////////////////////////////////////////////////
// DLL entry point
BOOL APIENTRY DllMain( HANDLE hModule, 
					   DWORD  ul_reason_for_call, 
					   LPVOID lpReserved
					 )
{
	g_hInstance = (HINSTANCE)hModule;
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			{
				if (!bka.InitAPI()) {
					return FALSE;
				}
				GetModuleFileName((HINSTANCE)hModule, szIni, _MAX_PATH);
				LPSTR lpExt = strrchr(szIni, '.');
				if (lpExt) {
					strcpy(lpExt, ".ini");
				} else {
					// just in case
					strcat(szIni, ".ini");
				}
				HDC hDC = GetDC(NULL);
				g_dpi = GetDeviceCaps(hDC, LOGPIXELSY);
				g_colors = GetDeviceCaps(hDC, BITSPIXEL) * GetDeviceCaps(hDC, PLANES);
				ReleaseDC(NULL, hDC);
				g_cxsmicon = ::GetSystemMetrics(SM_CXSMICON);
				g_cysmicon = ::GetSystemMetrics(SM_CYSMICON);

			}
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////////////
// Callbacks from Becky!

#ifdef __cplusplus
extern "C"{
#endif

////////////////////////////////////////////////////////////////////////
// Called when the program is started and the main window is created.
int WINAPI BKC_OnStart()
{
	/*
	Since BKC_OnStart is called after Becky!'s main window is
	created, at least BKC_OnMenuInit with BKC_MENU_MAIN is called
	before BKC_OnStart. So, do not assume BKC_OnStart is called
	prior to any other callback.
	*/
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when the main window is closing.
int WINAPI BKC_OnExit()
{
	// Return -1 if you don't want to quit.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when menu is intialized.
int WINAPI BKC_OnMenuInit(HWND hWnd, HMENU hMenu, int nType)
{
	switch (nType) {
	case BKC_MENU_MAIN:
		{
			/* Sample of adding menu items
			HMENU hSubMenu = GetSubMenu(hMenu, 4);
			// Define CmdProc as "void WINAPI CmdProc(HWND, LPARAM)"
			UINT nID = bka.RegisterCommand("Information about this Command", nType,CmdProc);
			AppendMenu(hSubMenu, MF_STRING, nID, "&Menu item");
			*/
			/* If needed, you can register the command UI update callback.
			// Define CmdUIProc as "UINT WINAPI CmdUIProc(HWND, LPARAM)"
			bka.RegisterUICallback(nID, CmdUIProc);
			*/
		}
		break;
	case BKC_MENU_LISTVIEW:
		break;
	case BKC_MENU_TREEVIEW:
		break;
	case BKC_MENU_MSGVIEW:
		break;
	case BKC_MENU_MSGEDIT:
		break;
	case BKC_MENU_TASKTRAY:
		break;
	case BKC_MENU_COMPOSE:
		break;
	case BKC_MENU_COMPEDIT:
		break;
	case BKC_MENU_COMPREF:
		break;
	default:
		break;
	}
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a folder is opened.
int WINAPI BKC_OnOpenFolder(LPCTSTR lpFolderID)
{
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a mail is selected.
int WINAPI BKC_OnOpenMail(LPCTSTR lpMailID)
{
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called every minute.
int WINAPI BKC_OnEveryMinute()
{
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a compose windows is opened.
int WINAPI BKC_OnOpenCompose(HWND hWnd, int nMode/* See COMPOSE_MODE_* in BeckyApi.h */)
{
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when the composing message is saved.
int WINAPI BKC_OnOutgoing(HWND hWnd, int nMode/* 0:SaveToOutbox, 1:SaveToDraft, 2:SaveToReminder*/) 
{
	// Return -1 if you do not want to send it yet.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a key is pressed.
int WINAPI BKC_OnKeyDispatch(HWND hWnd, int nKey/* virtual key code */, int nShift/* Shift state. 0x40=Shift, 0x20=Ctrl, 0x60=Shift+Ctrl, 0xfe=Alt*/)
{
	// Return TRUE if you want to suppress subsequent command associated to this key.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a message is retrieved and saved to a folder
int WINAPI BKC_OnRetrieve(LPCTSTR lpMessage/* Message source*/, LPCTSTR lpMailID/* Mail ID*/)
{
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when a message is spooled
int WINAPI BKC_OnSend(LPCTSTR lpMessage/* Message source */)
{
	// Return BKC_ONSEND_PROCESSED, if you have processed this message
	// and don't need Becky! to send it.
	// Becky! will move this message to Sent box when the sending
	// operation is done.
	// CAUTION: You are responsible for the destination of this
	// message if you return BKC_ONSEND_PROCESSED.

	// Return BKC_ONSEND_ERROR, if you want to cancel the sending operation.
	// You are responsible for displaying an error message.

	// Return 0 to proceed the sending operation.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when all messages are retrieved
int WINAPI BKC_OnFinishRetrieve(int nNumber/* Number of messages*/)
{
	// Always return 0.
	return 0;
}


////////////////////////////////////////////////////////////////////////
// Called when plug-in setup is needed.
int WINAPI BKC_OnPlugInSetup(HWND hWnd)
{
	// Return nonzero if you have processed.
	// return 1;
	return 0;
}


////////////////////////////////////////////////////////////////////////
// Called when plug-in information is being retrieved.
typedef struct tagBKPLUGININFO
{
	char szPlugInName[80]; // Name of the plug-in
	char szVendor[80]; // Name of the vendor
	char szVersion[80]; // Version string
	char szDescription[256]; // Short description about this plugin
} BKPLUGININFO, *LPBKPLUGININFO;

int WINAPI BKC_OnPlugInInfo(LPBKPLUGININFO lpPlugInInfo)
{
	/* You MUST specify at least szPlugInName and szVendor.
	   otherwise Becky! will silently ignore your plug-in.
	   */
	char sz[256];
	strcpy(lpPlugInInfo->szPlugInName, "Becky2! Multicolor Icons.");
	strcpy(lpPlugInInfo->szVendor, "RimArts, Inc.");
	strcpy(lpPlugInInfo->szVersion, "1.64");
	LoadString(g_hInstance, IDS_DESCRIPTION, sz, 255);
	strcpy(lpPlugInInfo->szDescription, sz);
	// Always return 0.
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Called when drag and drop operation occurs.
int WINAPI BKC_OnDragDrop(LPCSTR lpTgt, LPCSTR lpSrc, int nCount, int dropEffect)
{
	/*
	lpTgt:	A folder ID of the target folder.
			You can assume it is a root mailbox, if the string
			contains only one '\' character.
	lpSrc:	Either a folder ID or mail IDs. Multiple mail IDs are
			separated by '\n' (0x0a).
			You can assume it is a folder ID, if the string
			doesn't contain '?' character.
	nCount:	Number of items to be dropped.
			It can be more than one, if you drop mail items.
	dropEffect: Type of drag and drop operation
			1: Copy
			2: Move
			4: Link (Used for filtering setup in Becky!)
	*/
	// If you want to cancel the default drag and drop action,
	// return -1;
	// Do not assume the default action (copy, move, etc.) is always
	// processed, because other plug-ins might cancel the operation.
	return 0;
}


////////////////////////////////////////////////////////////////////////
// Returns requested image resources.
// Uncomment the statements in each case condition if you want to override 
// the default image resources.
// To return the resource identifier, assign a resource name to lppResourceName,
// or simply return a integer resource identifier as a return value.
// You can return bitmap resources with variable sizes. You must set the actual number of
// images to *pnImages
/* IMPORTANT!
 This callback is called by Becky! Ver.2.64 or later.
 Check nImage paramater first, and if your bitmap contains less images than that, you MUST NOT
 return your resource. This is very important to avoid the compatibility problem that can occur
 in the future releases.
*/
int WINAPI BKC_OnRequestResource2(int nType, int nImages, char** lppResourceName, int* pnImages)
{
	int nTemp = 0;
	BOOL bOldType = FALSE;
	if (!pnImages) {
		// Toolbar works with older version, but bitmaps are not.
		pnImages = &nTemp;
		bOldType = TRUE;
	}

	switch (nType) {
	case BKC_BITMAP_ADDRESSBOOKICON:
		// Icons for the tree view of the address book.
		// background = RGB(255,0,255) (purple)

		if (nImages <= 6) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "ADDRESSBOOKICON_120";
			} else {
				*lppResourceName = "ADDRESSBOOKICON";
			}
			*pnImages = 6;
		}
		break;
	case BKC_BITMAP_ADDRESSPERSON:
		// Icons for the list view of the address book.
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 7) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "ADDRESSPERSON_120";
			} else {
				*lppResourceName = "ADDRESSPERSON";
			}
			*pnImages = 7;
		}
		break;
	case BKC_BITMAP_ANIMATION:
		// Bitmap animation at the top-right of the main window.
		// 30 * 30 * nVariable
	
		*lppResourceName = "ANIMATION";
		*pnImages = 9;

		break;
	case BKC_BITMAP_FOLDERCOLOR:
		// Selection of the colored folder icon, which are extracted from "BKC_BITMAP_FOLDERICON".
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 5) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "FOLDERCOLOR_120";
			} else {
				*lppResourceName = "FOLDERCOLOR";
			}
			*pnImages = 5;
		}
		break;
	case BKC_BITMAP_FOLDERICON:
		// Icons for the tree view of the main window.
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)
		if (nImages <= 40) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "FOLDERICON_120";
			} else {
				*lppResourceName = "FOLDERICON";
			}
			*pnImages = 40;
		}
		break;
	case BKC_BITMAP_LISTICON:
		// Icons for the list view of the main window.
		// 32 * 15 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 21) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "LISTICON_120";
			} else {
				*lppResourceName = "LISTICON";
			}
			*pnImages = 21;
		}
		break;
	case BKC_BITMAP_LISTICON2:
		// Additional Icons for the list view of the main window.
		// 32 * 15 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 21) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "LISTICON2_120";
			} else {
				*lppResourceName = "LISTICON2";
			}
			*pnImages = 21;
		}
		break;
	case BKC_BITMAP_PRIORITYSTAMP:
		// Icons for selecting priority in the composing window.
		// 18 * 20 * nFixed

		if (nImages <= 5) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "PRIORITYSTAMP_120";
			} else {
				*lppResourceName = "PRIORITYSTAMP";
			}
			*pnImages = 5;
		}
		break;
	case BKC_BITMAP_RULETREEICON:
		// Icons for the tree view of the filtering manager.
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 6) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "RULETREEICON_120";
			} else {
				*lppResourceName = "RULETREEICON";
			}
			*pnImages = 6;
		}
		break;
	case BKC_BITMAP_TEMPLATEFOLDER:
		// Icons for the tree view of the template selecting dialog.
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 6) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "TEMPLATEFOLDER_120";
			} else {
				*lppResourceName = "TEMPLATEFOLDER";
			}
			*pnImages = 6;
		}
		break;
	case BKC_BITMAP_WHATSNEWLIST:
		// Icons for the list in "What's New" list.
		// 16 * 16 * nFixed
		// background = RGB(255,0,255) (purple)

		if (nImages <= 2) {
			if (g_dpi >= 120 && !bOldType) {
				*lppResourceName = "WHATSNEWLIST_120";
			} else {
				*lppResourceName = "WHATSNEWLIST";
			}
			*pnImages = 2;
		}
		break;

	case BKC_ICON_ADDRESSBOOK:
		// An icon for the address book.
		// 32 * 32
		// 16 * 16
		if (g_dpi >= 120 && !bOldType) {
			*lppResourceName = "ADDRESSBOOK_120";
		} else {
			*lppResourceName = "ADDRESSBOOK";
		}
		*pnImages = 1;
		break;
	case BKC_ICON_ANIMATION1_SMALL:
		// An icon for the task tray animation(progress) 1
		// 16 * 16

		*lppResourceName = "ANIMATION1_SMALL";
		*pnImages = 1;
		break;
	case BKC_ICON_ANIMATION2_SMALL:
		// An icon for the task tray animation(progress) 2
		// 16 * 16

		*lppResourceName = "ANIMATION2_SMALL";
		*pnImages = 1;
		break;
	case BKC_ICON_COMPOSEFRAME:
		// An icon for the composing window.
		// 32 * 32
		// 16 * 16

		*lppResourceName = "COMPOSEFRAME";
		*pnImages = 1;
		break;
	case BKC_ICON_MAINFRAME:
		// An icon for the main window. However, it is only used in the tasktray.
		// 32 * 32
		// 16 * 16

		*lppResourceName = "MAINFRAME";
		*pnImages = 1;
		break;
	case BKC_ICON_NEWARRIVAL1_SMALL:
		// An icon for the task tray animation(new messages) 1
		// 16 * 16

		*lppResourceName = "NEWARRIVAL1_SMALL";
		*pnImages = 1;
		break;
	case BKC_ICON_NEWARRIVAL2_SMALL:
		// An icon for the task tray animation(new messages) 2
		// 16 * 16

		*lppResourceName = "NEWARRIVAL2_SMALL";
		*pnImages = 1;
		break;

	// For some reason, it is better to use integer resource ID
	// instead of resource name for toolbars.
	case BKC_TOOLBAR_ADDRESSBOOK:
		// A toolbar for the address book.

		if (nImages <= 9) {
			*pnImages = 9;
			if (g_dpi >= 120) {
				return IDR_ADDRESSBOOK_120;
			} else {
				return IDR_ADDRESSBOOK;
			}
		}
		break;
	case BKC_TOOLBAR_COMPOSEFRAME:
		// A toolbar for the composing window.

		if (nImages <= 22) {
			*pnImages = 23;
			if (g_dpi >= 120) {
				return IDR_COMPOSEFRAME_120;
			} else {
				return IDR_COMPOSEFRAME;
			}
		}
		break;
	case BKC_TOOLBAR_HTMLEDITOR:
		// A toolbar for the WYSWYG HTML editor.

		if (nImages <= 17) {
			*pnImages = 17;
			if (g_dpi >= 120) {
				return IDR_HTMLEDITOR_120;
			} else {
				return IDR_HTMLEDITOR;
			}
		}
		break;
	case BKC_TOOLBAR_MAINFRAME:
		// A toolbar for the main window.
		if (nImages <= 37) {
			*pnImages = 37;
			if (g_dpi >= 120) {
				return IDR_MAINFRAME_120;
			} else {
				return IDR_MAINFRAME;
			}
		}
		break;
	default:
		break;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////
// Returns requested image resources.
// Uncomment the statements in each case condition if you want to override 
// the default image resources.
// To return the resource identifier, assign a resource name to lppResourceName,
// or simply return a integer resource identifier as a return value.
/* IMPORTANT!
 This callback is for the compatibility for Becky! Ver. 2.63 or older.
 You can modify the image in the sample resource file, but you can not change the size and order
 of the bitmap.
 You can, however, modify the button size of toolbar resources, although you can not change
 the order and the assigned command IDs for buttons.
 Check nImage paramater first, and if your bitmap contains less images than that, you MUST NOT
 return your resource. This is very important to avoid the compatibility problem that can occur
 in the future releases.
*/
int WINAPI BKC_OnRequestResource(int nType, int nImages, char** lppResourceName)
{
	return BKC_OnRequestResource2(nType, nImages, lppResourceName, NULL);
}


#ifdef __cplusplus
}
#endif